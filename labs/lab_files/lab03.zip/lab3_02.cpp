/* file: lab3.cpp

   Author: ***PLACE YOUR NAME HERE***
   CS1428.***SECTION NUMBER***
   ***PLACE DATE HERE***
   
   This program will ask (prompt) the user to enter a 6 digit customerID 
   which is an integer number.
   The program will read the quantity of a particular item and its price 
   from an input file named Purchase_Details.
   It will then print out the customer id and the total price to an output file 
   and to the screen.
   
   See a sample of what the output should look like below:
   	   
   	   Customer ID:		   675432
   	   Total Bill:		$   56.78

*/

// Insert the appropriate include directives here.

using namespace std;

int main()
{
	//define an input file variable named dataIn here.
    
    //define an output file variable named dataOut here.
    
    int quantity,			//contains the amount of items purchased
		customerID;         /*contains the customer id entered from 
									   the keyboard */ 
    float itemprice,        //contains the price of each item
    	  totalBill;        // contains the bill, i.e. the price of all items
    
    //Write the statement to open the input file "Purchase_details.txt"
    
    //Write the statement to open the output file "Bill.txt"
    
	//Prompt (ask) the user to enter his/her customer ID
    
	//Write the input statement that reads the quantity and price of the item 
    //from the input file
    
    //Write the assignment statement that determines the total bill
    //(quantity * itemprice)
    
    //Write the output statement that prints the customer ID, total bill, 
	//with a label, to the output file
    //use setw and setprecision to format your ouput
    
    //Write the output statement that prints the customer ID, total bill, 
	//with a label, to the screen
    //use setw and setprecision to format your ouput
   
    return 0;
     
}
