//============================================================================
// Name        : Your name goes here
// Lab         : 1
//============================================================================

#include <iostream>
using namespace std;

int main()
{
   //named constants go here

   //variables go here
   
   //Display menu
   cout  << "This is my Minesweeper game." << endl << endl
		  << "Choose one of the options below:" << endl
		  << "(1) Start Game" << endl
		  << "(2) View Best Times" << endl
		  << "(3) Quit" << endl << endl
		  << "Enter Selection: ";
		  
		  
   //Display gameboard
	
	
	
	return 0;
}
