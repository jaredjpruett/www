#include <iostream>

using namespace std;

void qualified();
void notQualified();

int main()
{
	
	
	return 0;
}

void qualified()
{
	// Define the qualified function HERE!
}

void notQualified()
{
	// Define the notQualified function HERE!
}